import { Injectable } from '@angular/core';
import { createClient, Entry } from 'contentful';
const CONFIG = {
  space: 'wl1z0pal05vy',
  accessToken:
    '0e3ec801b5af550c8a1257e8623b1c77ac9b3d8fcfc1b2b7494e3cb77878f92a',

  contentTypeIds: {
    product: '2PqfXUJwE8qSYKuM0U6w8M',
  },
};

@Injectable({
  providedIn: 'root'
})
export class ContentfulService {
  private cdaClient = createClient({
    space: 'tlqfiok8qhck',
    environment: 'test', // defaults to 'master' if not set
    accessToken: 'KQ17Gazu9xSq2yNvwDDOASVkxTvF55SOAkE0_6BRzmY',
    host: 'cdn.contentful.com'
  });

  constructor() {
  }

  getProducts(noOfRecords: number, skip: number): Promise<Entry<any>[]> {
    // skip=0, limit=15 Page 2: skip=15, limit=15 Page 3: skip=30, limit=15.
    // const client = createClient({
    //   space: 'tlqfiok8qhck',
    //   environment: 'test', // defaults to 'master' if not set
    //   accessToken: 'KQ17Gazu9xSq2yNvwDDOASVkxTvF55SOAkE0_6BRzmY',
    //   host: 'cdn.contentful.com'
    // });

    // client.getContentTypes('blogPost')
    //   .then((response) => console.log(response))
    //   .catch(console.error)
    return this.cdaClient.getEntries(Object.assign({
      content_type: 'blogPost',
      limit: noOfRecords,
      skip
    }))
      .then(res => res.items);

  }
}
